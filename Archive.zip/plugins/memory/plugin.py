import json
import uuid
from typing import List

# todo remove this for context call
from belllm.utils import get_root_dir as _get_root_dir

# todo plugins allow for only functions without a leading '_'.
#  run debug mode option
#  todo handle local  vs global context

MEMORY_BANK_PATH = _get_root_dir() / "memory-bank.json"


def _load_memory_bank():
    if MEMORY_BANK_PATH.exists():
        with open(MEMORY_BANK_PATH, "r") as f:
            return json.load(f)
    return []


def _save_memory_bank(memory_bank: List[dict]):
    with open(MEMORY_BANK_PATH, "w+") as f:
        f.write(json.dumps(memory_bank, indent=4))


def _save_memory(content: str):
    memory_bank = _load_memory_bank()
    memory_bank.append({"id": str(uuid.uuid4()), "content": content})
    _save_memory_bank(memory_bank)


def _initialise():
    if MEMORY_BANK_PATH.exists():
        with open(MEMORY_BANK_PATH, "r") as f:
            return f.read()
    return None


def save_to_memory_bank(content: str):
    """Save a message in the memory bank such that it will be given to an llm. This should be used
    as it may provide useful context to the llm. Don't save everything, but save things that are
    general and applicable to the user that may be useful for future prompts. Any information you
    learn about the used should be stored such that the LLM can use it to know about the user.

    Important: You should frame the content briefly, concisely and in a clear format to
        instruct another LLM.

    Args:
        content: The message being saved. This should be in the format that it can be
            used to instruct an LLM.

    Returns:
        Ok if save was successful or the error message otherwise. Repeated executions of a failure may not work.
    """
    print("Memory saved!", content)
    _save_memory(content)
    return f"Saved {content}!"


def _cli(args: List[str]):
    if len(args) < 1:
        print("Usage: belllm memory <help|list|save|delete|wipe>")
        return

    command = args[0]
    if command == "help":
        print("`belllm memory help`: Shows this help message")
        print("`belllm memory list`: List memories")
        print("`belllm memory save <message>`: Save a message to the memory bank")
        print("`belllm memory delete <memory id>`: Delete a memory from the memory bank")
        print("`belllm memory wipe`: Clear the memory bank")

    elif command == "list":
        memories = _load_memory_bank()
        for memory in memories:
            print(memory.get("id"), memory.get("content"))

    elif command == "save":
        if len(args) < 2:
            print("No message provided")
            return
        _save_memory(" ".join(args[1:]))

    elif command == "delete":
        if len(args) != 2:
            print("Please provide a memory id to delete")
            return

        memories = _load_memory_bank()
        memory_found = False
        for memory in memories:
            if memory.get("id") == args[1]:
                memory_found = True
                break

        if not memory_found:
            print("Memory not found")
            return

        memories = [memory for memory in memories if memory.get("id") != args[1]]
        _save_memory_bank(memories)
        print("Memory deleted")

    elif command == "wipe":
        _save_memory_bank([])

