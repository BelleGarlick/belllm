from typing import Union


def run(
    type: Union[int, str] | None = None,
) -> Union[dict, None]:
    """This function allows you to create a workout in tidalflow.

    :param type: An optional value
    :return:
    """
    return "Workout created! Workout: 10"
